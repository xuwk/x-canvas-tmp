/**
 * @module xc.core
 */
xc.depends([
    "lang.js",
    "class.js",
    "module.js"
]);
